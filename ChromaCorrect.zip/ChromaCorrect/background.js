console.log("Background running");
chrome.browserAction.onClicked.addListener(IconClicked);
function IconClicked(tab)
{
	let msg = {
		txt : "Color"
	}
	chrome.tabs.sendMessage(tab.id,msg);
}