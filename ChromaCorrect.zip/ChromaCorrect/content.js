chrome.runtime.onMessage.addListener(gotMessage);
function gotMessage(message,sender,sendresponse)
{
    console.log(message.txt);
    let paragraphs = document.getElementsByTagName("p");
    let hyperlinks = document.getElementsByTagName("a");
    let otherparagraphs = document.getElementsByTagName("div");
    let lists = document.getElementsByTagName("li");
    let td = document.getElementsByTagName("td");
    let th = document.getElementsByTagName("th");
    let main = document.getElementsByTagName("main");
    for(elt of paragraphs)
    {
        elt.style['background-color'] = '#c2edea';
        elt.style['color'] = '#463F3A';
    }
    for(elt of hyperlinks)
    {
        elt.style['background-color'] = '#c2edea';
        elt.style['color'] = '#EF6706';
    }
    for(elt of lists)
    {
    elt.style['background-color'] = '#c2edea';
    elt.style['color'] = '#463F3A';
    }
    for(elt of otherparagraphs)
    {
        elt.style['background-color'] = '#c2edea';
        elt.style['color'] = '#463F3A';
    }
    for(elt of td)
    {
        elt.style['background-color'] = '#c2edea';
        elt.style['color'] = '#463F3A';
    }
    for(elt of th)
    {
        elt.style['background-color'] = '#c2edea';
        elt.style['color'] = '#463F3A';
    }
    for(elt of main)
    {
        elt.style['background-color'] = '#c2edea';
        elt.style['color'] = '#463F3A';
    }
}
